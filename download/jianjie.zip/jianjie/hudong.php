<!DOCTYPE html>
<html>
<head>
<!--网页格式文本，编码UTF-8  -->
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>web作业</title>
<!--链接外部css样式表文件-->
<link href="css/style.css" rel="stylesheet" type="text/css" />

</head>
<body>
	<!--主体框导航条  -->
<?php include"header.php";?> 

<div class="cleaner"></div>
<div id="container">
  <div class="dm"> 
    <!-- 代码 开始 -->
    <div id="yc-mod-slider">
		<!--wrapper达到俩边留空目的-->
      <div class="wrapper">
		  <!--jQuery幻灯片插件-->
        <div id="slideshow" class="box_skitter fn-clear">
          <ul><!--放入图片-->
            <li> <img class="cubeRandom" src="images/dm1.jpg" /></li>
            <li> <img   class="cubeRandom" src="images/dm2.jpg" /></li>
            <li> <img   class="cubeRandom" src="images/dm3.jpg" /></li>
          </ul>
        </div>
		<!--导入幻灯片效果脚本-->
        <script type="text/javascript" src="js/slideshow.js"></script> 
      </div>
    </div>
    <!-- 代码 结束 --> 
  </div>
  <div class=" clear"></div>
  <div id="content_area">
    <div class="title_left">
      <h1>生活展示</h1>
    </div>
    <div class="cleaner"></div>
    <p>﻿大一的课程十分简单，由于我的不上心，虽不至于挂科，但是绩点却是较低，导致在之后的专业分流与选择上，丧失了很多的主动权与选择权。
<br/>大一的前车之鉴，之后的学习中，我将更加认真对待学习，后面的课程逐渐加大难度，即使这样，我也希望自己能够得到较高分数，在之后的考研道路上能够顺利许多。</p>
  <br/><!-- 使用vedio视频标签播放iuMP4演唱会视频 --> 
    <p align="center"><video src="video/1.mp4" type="video/mp4" width="100%" controls="controls" autoplay></video></p>
    <div class="cleaner"></div>
  </div>
  <!-- End Of Content area-->
  <div class="share">
    <div class="cleaner"></div>
  </div>
  <div id="footer"> Copyright © 毛宇航个人主页</div>
</div>
<!-- End Of Container -->
</body>
</html>
