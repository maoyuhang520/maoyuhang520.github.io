<!DOCTYPE html>
<html>
<head>
<!--网页格式文本，编码UTF-8  -->
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>web作业</title>
<!--链接外部css样式表文件-->
<link href="css/style.css" rel="stylesheet" type="text/css" />
<!--插入背景音乐-自动播放-无限循环 -->
<embed autostart="true" loop="-1" controls="ControlPanel" width="0" height="0" src="music/1.mp3">
</head>
<body>
	<!--主体框导航条  -->
<?php include"header.php";?> 

<div class="cleaner"></div><!--透明白框-->
<div id="container">
  <div class="clear"></div>
  <div id="content_area"><!--左对齐-->
    <div class="left_main">
      <div class="title_left">
        <h1>生活感悟</h1>
      </div> <!--清除子集的浮动-->
      <div class="cleaner"></div>
      <div class="xinshang">香港大学孙教授说：“大学，就应该是早起吃点早餐；跑跑步；专业课认真听；公共课看看自己喜欢的杂志；中午小睡一会儿；下午参加个社团活动或打打篮球；晚上陪着喜欢的人散散步；或去自习室安静地看看书…… 社会不需要学霸，也不认什么学生会主席，更不希望看到学生放弃学业去创业。你只要能平稳完整地读完大学，寻找到自己所爱的人和兴趣，多去没有目的的看些能丰富自己思想的书，认识几个好的不成样子的朋友，锻炼或是塑造自己的身体，学精自己想要从事事业的专业知识…… 做到这些，平淡地度过大学这几年你就已经足够优秀了。”
<br/>人生到了现在，一直在不停的上学读书，生活像是只有学习，上了大学，便是需要逐渐改变的时候了。大学就是从校园迈入社会的过渡期，过好这段时间很重要，不要仅仅把时间花在学习之上。<div class="cleaner"></div>
      </div><!--插入图片（居中）-->
      <p align="center"><img src="images/p6.jpg" /></p>
      <p></p>
    </div> <!--清除子集的浮动-->
    <div class="cleaner"></div>
  </div>
  <!-- End Of Content area-->
  <div class="share"> <!--清除子集的浮动-->
    <div class="cleaner"></div>
  </div>
  <div id="footer"> Copyright © 毛宇航个人主页</div>
</div>
<!-- End Of Container -->
</body>
</html>
