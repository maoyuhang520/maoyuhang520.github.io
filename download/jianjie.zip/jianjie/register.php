<!DOCTYPE html>
<html>
<head>
<!--网页格式文本，编码UTF-8  -->
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>web作业</title>
<!--链接外部css样式表文件-->
<link href="css/style.css" rel="stylesheet" type="text/css" />
<!--插入背景音乐-自动播放-无限循环 -->
<embed autostart="true" loop="-1" controls="ControlPanel" width="0" height="0" src="music/1.mp3">
</head>
<body>
	<!--主体框导航条  -->
<?php include"header.php";?> 

<div class="cleaner"></div><!--注册页面设计-->
<div id="container"><!--嵌套盒子模型-->
  <div class=" clear"></div>
  <div id="content_area">
    <div class="youji_main">
      <div class="title_left">
        <h1>注册</h1>
      </div><!--清除子集的浮动-->
      <div class="cleaner"></div>
      <p>&nbsp;</p><!--空格换行-->
      <p>&nbsp;</p>
<p></p>
      <p></p>
      <p></p>
      <form action="rein.php" method="post">
	
      <div class="Contact_input">
        <p>用户名</p>
        <input class="c_input" type="text" name="user" />
        <p>密码</p><!--输入6~16位字符密码的文本框-离开字段时验证-->
        <input class="c_input"  type="password" id="password" name="password" onBlur="check_psw_login()" required="required" placeholder="6~16位字符">
        <p>确认密码</p>
        <input class="c_input" />
        <p>&nbsp;</p>
<div ><input class="SUB" style="color: #fff;border-style: none;" type="submit" value="注册"/></div>
        <p></p>
      </div><!--插入武汉纺织大学图案-->
      	      
      </form>
      <img class="fr" style="margin-top:50px;" src="images/c_map.jpg" width="350" />
    </div><!--清除子集的浮动-->
    <div class="cleaner"></div>
  </div>
  <!-- End Of Content area-->
  <div class="share"><!--清除子集的浮动-->
    <div class="cleaner"></div>
  </div>
   <div id="footer"> Copyright © 毛宇航个人主页</div>
</div>
<!-- End Of Container -->
</body>
</html>
