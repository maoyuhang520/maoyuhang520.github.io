<!DOCTYPE html>
<html>
<head>
<!--网页格式文本，编码UTF-8  -->
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>web作业</title>
<!--链接外部css样式表文件-->
<link href="css/style.css" rel="stylesheet" type="text/css" />
<!--插入背景音乐-自动播放-无限循环 -->
<embed autostart="true" loop="-1" controls="ControlPanel" width="0" height="0" src="music/1.mp3">
</head>
<body>
	<!--主体框导航条  -->
<?php include"header.php";?> 
<!--清除子集的浮动；浮动就是你给html元素加了float样式后，
那么这个元素在文档中是不占文档流的。那样下面的元素就可能跑到你浮动元素的位置，
这样文档排版会乱掉。clear的意思就是不靠近浮动元素的样子了。
这种情况下往往需要像你这样加一个空的div来占位 -->
<div class="cleaner"></div>
<!--淡白色主体框-->
<div id="container">
  <div class="dm"> 
    <!-- 代码 开始 -->
    <div id="yc-mod-slider">
		<!--wrapper达到俩边留空目的-->
      <div class="wrapper">
		  <!--jQuery幻灯片插件-->
        <div id="slideshow" class="box_skitter fn-clear">
          <ul><!--放入图片-->
            <li> <img class="cubeRandom" src="images/dm1.jpg" /></li>
            <li> <img   class="cubeRandom" src="images/dm2.jpg" /></li>
            <li> <img   class="cubeRandom" src="images/dm3.jpg" /></li>
          </ul>
        </div>
		<!--导入幻灯片效果脚本-->
        <script type="text/javascript" src="js/slideshow.js"></script> 
      </div>
    </div>
    <!-- 代码 结束 --> 
  </div>
  <!--清除子集的浮动-->
  <div class=" clear"></div>
    <!--平时爱好框-->
  <div id="content_area">
       <div class="title_left">
        <h1>平时爱好</h1>
      </div>
      <div class="cleaner"></div>
       <div id="zp">
      <p>平时喜欢运动，虽然我的个子不高，但是特别喜欢打羽毛球，羽毛球已经是我生命中不可缺少的一部分。
<br/>平时的生活中，我比较活泼开朗，认识许多志同道合的朋友，在步入大学后，也是能够很快的适应大学生活。我经常和室友，球队的朋友外出聚会等，在朋友遇到困难时，也能够主动伸出援助之手...</p>
          <!--居中显示图片-->
	  <p align="center"><img src="images/p2.jpg" /></p>
     <div class="cleaner"></div>
  </div>
  <!-- End Of Content area-->
  <div class="share">
    <div class="cleaner"></div>
  </div>
  
  <div id="footer"> Copyright © 毛宇航个人主页</div>
</div>
<!-- End Of Container -->
</body>
</html>
