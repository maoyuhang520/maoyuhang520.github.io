<?php
require_once ('admin/db.php');
$user=$_POST['user'];
$password=$_POST['password'];
$dates=date('Y-m-d');
$sql="INSERT INTO user(user,password,dates)VALUES('$user', '$password', '$dates')";//数据库查询语句
mysqli_query($conn,'set names utf8');//连接数据库表
if(mysqli_query($conn,$sql)){
    echo"<script>alert('success'); window.location.href='login.php';</script>";
}else{
   echo"<script>alert('error'); window.location.href='register.php';</script>";
}
?>