<?php session_start();?>
<div class="index_list">
  <ul><!--网页超链接小标题-->
  	<li> <a href="index.php">首页</a> </li>
    <li> <a href="jingli.php">个人简介</a> </li>
    <li> <a href="zuopin.php">平时爱好</a> </li>
    <li> <a href="hudong.php">生活展示</a> </li>
     <li> <a href="news.php">站内资讯</a> </li>
    <li> <a href="huojiang.php">大学学习</a> </li>
    <li> <a href="pinjia.php">生活感悟</a> </li>
    
    
    <?php
    if(isset($_SESSION['user'])){
	    
	   echo"
	   <li> <a href='message.php'>在线留言</a> </li>
	   <li> <a href='exit.php'>退出</a> </li>  ";
    }else{
	   echo" 
	   <li> <a href='login.php'>登录</a> </li>
	   <li> <a href='register.php'>注册</a> </li>  ";
	    
    }?>
    
   
  </ul>
</div><!--清除子集的浮动-->