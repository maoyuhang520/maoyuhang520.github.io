<!DOCTYPE html>
<html>
<head>
<!--网页格式文本，编码UTF-8  -->
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>web作业</title>
<!--链接外部css样式表文件-->
<link href="css/style.css" rel="stylesheet" type="text/css" />

</head>
<body>
	<!--主体框导航条  -->
<?php include"header.php";?> 

<div class="cleaner"></div>
<div id="container">
  <div class="dm"> 
    <!-- 代码 开始 -->
    <div id="yc-mod-slider">
		<!--wrapper达到俩边留空目的-->
      <div class="wrapper">
		  <!--jQuery幻灯片插件-->
        <div id="slideshow" class="box_skitter fn-clear">
          <ul><!--放入图片-->
            <li> <img class="cubeRandom" src="images/dm1.jpg" /></li>
            <li> <img   class="cubeRandom" src="images/dm2.jpg" /></li>
            <li> <img   class="cubeRandom" src="images/dm3.jpg" /></li>
          </ul>
        </div>
		<!--导入幻灯片效果脚本-->
        <script type="text/javascript" src="js/slideshow.js"></script> 
      </div>
    </div>
    <!-- 代码 结束 --> 
  </div>
  <div class=" clear"></div>
  <div id="content_area">
    <div class="title_left">
      <h1>站内资讯</h1>
    </div>
    <div class="cleaner"></div>
    <div class="news" style="height: 500px;">
    <?php
    		 require_once ('admin/db.php');
    		 
    		 $sql="SELECT * FROM news order by nid desc  limit 5   ";//数据库查询语句
    		 mysqli_query($conn,'set names utf8');
    		 $news=mysqli_query($conn,$sql);//查询出数据并赋值
    		 header("Content-type: text/html; charset=utf-8");//头部文件
       
    		 while($newsall=mysqli_fetch_assoc($news)) {
			 
			 
			 echo"<li><a href='cont.php?id=".$newsall['nid']."'>".$newsall['title']."</a><span style='float:right'>".$newsall['dates']."</span></li>";
			 
			 
		 }
		 
		 
		 
		 ?>
   
   
   </div>
   
   
 
  </div>
  <!-- End Of Content area-->
  <div class="share">
    <div class="cleaner"></div>
  </div>
  <div id="footer"> Copyright © 毛宇航个人主页</div>
</div>
<!-- End Of Container -->
</body>
</html>
