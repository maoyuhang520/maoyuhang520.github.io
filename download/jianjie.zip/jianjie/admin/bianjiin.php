<?php
require_once ('db.php');
$title=$_POST['title'];
$content=$_POST['content'];
$id=$_POST['id'];

    $sql="UPDATE news SET title ='$title',content='$content'  WHERE nid = $id";//数据库查询语句。更新
    mysqli_query($conn,'set names utf8');//连接数据库表
    if(mysqli_query($conn,$sql)){
    
       echo"<script>alert('success'); window.location.href='news.php';</script>";
    }else{
    
       echo"<script>alert('error'); window.location.href='news.php';</script>";
    }
   










?>
