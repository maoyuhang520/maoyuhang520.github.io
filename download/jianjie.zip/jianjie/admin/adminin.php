<?php
session_start();
require_once ('db.php');
$admin=$_POST['admin'];
$password=$_POST['password'];
$shuju="SELECT * FROM admin  WHERE admin='$admin'";//数据库查询语句
mysqli_query($conn,'set names utf8');//连接数据库表
$shujuone=mysqli_query($conn,$shuju);//查询出数据并赋值
$shujus=mysqli_fetch_assoc($shujuone);
if(!isset($shujus)){
    echo"<script>alert('登录错误！'); window.location.href='index.php';</script>";
}else{
   
    if($shujus['password']==$password){
        $_SESSION['admin']=$shujus['admin'];
	 echo
	 "<script>alert('登录成功！'); window.location.href='news.php';</script>";
       
    }else{

        echo"<script>alert('登录错误！'); window.location.href='index.php';</script>";
    }


}







?>
<?php
