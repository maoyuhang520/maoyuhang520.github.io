<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>管理员后台</title>
<link href="css/style.css" rel="stylesheet" type="text/css"/>
<script src="js/jquery.min.js" type="text/javascript"></script>
<script>
	$(function(){
		
		$(".left").height($(window).height());
		
		$(".right").height($(window).height());

		
	})
	
	
</script>


</head>

<body class="bj">

   <?php include"left.php";?>
   
   <div class="right">
	 
	                
	  
           <h1>新闻发布</h1>
           <hr/>
           <form action="addnewsin.php" method="post"  enctype="multipart/form-data"  class="add">
                
                  <input type="text" placeholder="输入博客标题" name="title" class="addtext"/><br/><br/>
                  <textarea id="editor_id" style="height:400px;" placeloder="输入内容" name="content"></textarea>
                  <input type="submit" value="添加" class="addsub"/>
           
           </form>
	   
	  
	   
	   
   </div>
   
   <script charset="utf-8" src="kindeditor/kindeditor-all.js"></script>
   <script charset="utf-8" src="kindeditor/lang/zh-CN.js"></script>
   <script>
           KindEditor.ready(function(K) {
                   window.editor = K.create('#editor_id');
           });
   </script>
      

</body>
</html>