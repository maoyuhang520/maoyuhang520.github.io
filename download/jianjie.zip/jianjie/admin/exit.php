<?php
session_start();//开启session
require_once ('db.php');
if(session_destroy()){
    
       echo"<script>alert('退出成功'); window.location.href='index.php';</script>";
    }else{
    
       echo"<script>alert('退出失败'); window.location.href='index.php';</script>";
    }
   







?>
