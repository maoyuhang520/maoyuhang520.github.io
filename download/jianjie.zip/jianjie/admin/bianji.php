<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>管理员后台</title>
<link href="css/style.css" rel="stylesheet" type="text/css"/>
<script src="js/jquery.min.js" type="text/javascript"></script>
<script>
	$(function(){
		$(".left").height($(window).height());
		$(".right").height($(window).height());
	})
	
	
</script>


</head>

<body class="bj">

   <?php include"left.php";?>
   
   <div class="right">
      
             <h1>编辑新闻</h1>
             <hr/>
             <form action='bianjiin.php' method='post' enctype="multipart/form-data" class='add'>
              <?php
		     require_once ('db.php');
		     $id=$_GET['id'];
		     $sql = "select * from news where nid='$id'"  ;//数据库查询
		     mysqli_query($conn,'set names utf8');
		     $res=mysqli_query($conn,$sql);//查询出数据并赋值
		     header("Content-type: text/html; charset=utf-8");//头部文件

            while($ros=mysqli_fetch_assoc($res)) {
			
			   echo"      
				
				     
			             <input type='text' value='".$ros['title']."' name='title' class='addtext'/><br/><br/>
			                       
			             <textarea id='editor_id' style='height:400px;' placeloder='输入内容' name='content'>".$ros['content']."</textarea>
			                     
			             <input type='hidden' value='".$ros['nid']."' name='id'/>   
					     
			             <input type='submit' value='修改' class='addsub'/>
			   ";
			}
			?>
            
      
      
              </form> 
      
      
      </div>
      
  
      
      <script charset="utf-8" src="kindeditor/kindeditor-all.js"></script>
      <script charset="utf-8" src="kindeditor/lang/zh-CN.js"></script>
      <script>
              KindEditor.ready(function(K) {
                      window.editor = K.create('#editor_id');
              });
      </script>
      

</body>
</html>