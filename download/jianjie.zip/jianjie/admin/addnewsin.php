<?php
require_once ('db.php');
$title=$_POST['title'];
$content=$_POST['content'];
$dates=date("Y/m/d h:m:s");
$sql="INSERT INTO news(title,content,dates)VALUES('$title', '$content','$dates')";//数据库查询语句
mysqli_query($conn,'set names utf8');//连接数据库表
if(mysqli_query($conn,$sql)){
    echo"<script>alert('success'); window.location.href='news.php';</script>";
}else{
   echo"<script>alert('error'); window.location.href='news.php';</script>";
}
?>

