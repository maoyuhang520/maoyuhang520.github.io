<?php
require_once ('db.php');
$id=$_GET['id'];//获取删除news_id
$sql="DELETE FROM message WHERE mid=$id";//数据库查询语句。删除语句
mysqli_query($conn,'set names utf8');//连接数据库表
if(mysqli_query($conn,$sql)){

      echo"<script>alert('删除成功！'); window.location.href='message.php';</script>";
 

}else{
  echo"<script>alert('删除失败！'); window.location.href='message.php';</script>";
  
}






?>
