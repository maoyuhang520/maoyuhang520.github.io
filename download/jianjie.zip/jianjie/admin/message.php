<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>管理员后台</title>
<link href="css/style.css" rel="stylesheet" type="text/css"/>
<script src="js/jquery.min.js" type="text/javascript"></script>
<script>
	$(function(){
		$(".left").height($(window).height());
		
		$(".right").height($(window).height());
	
		
	})
	
	
</script>


</head>

<body class="bj">

   <?php include"left.php";?>
   
   <div class="right">
	   
	   <h1>新闻管理</h1>
	                
	   <table width="1000" border="0" cellspacing="0" cellpadding="0" class="news_table">
	     <tr class="topt">
	       <td>编号</td>
	       <td>留言人：</td>
	       <td>留言内容</td>
		<td>留言日期</td>
	       <td>删除</td>
	     
	     </tr>
	      <?php
		 require_once ('db.php');
		 
		 $sql="SELECT * FROM message   order by mid desc";//数据库查询语句
		 mysqli_query($conn,'set names utf8');
		 $news=mysqli_query($conn,$sql);//查询出数据并赋值
		 header("Content-type: text/html; charset=utf-8");//头部文件
   
		 while($newsall=mysqli_fetch_assoc($news)) {	
		   echo"
	   			
	       <tr>
	      
	       <td>".$newsall['mid']."</td>
	       <td>".$newsall['title']."</td>
		 <td>".$newsall['content']."</td>
	       <td>".$newsall['dates']."</td>
	   			
	     
	       <td><a style='color:red;'  href='mdelete.php?id=".$newsall['mid']."'>✘</a></td>
	     </tr>";
	   
	     }
	   
	       ?>
	   </table>
	   

	         
	 </div>
	   
	  
	   
	   
   </div>
   
      

</body>
</html>