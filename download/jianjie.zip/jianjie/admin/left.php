 <?php
 session_start();
 if(!isset($_SESSION['admin'])){
	 
	  echo"<script>alert('没有登录，不能直接访问后台。'); window.location.href='index.php';</script>";
	 
 }

 
 ?>
 <div class="left">
	   
	   <div class="top"><img src="images/logo.png"/><span>个人网站管理</span></div>
	   <hr/>
	   
	   <div class="nav">
		   
		   <li><a href="news.php"><img src="images/c1.png"/><span>新闻管理</span></a></li>
		   <li><a href="addnews.php"><img src="images/c1.png"/><span>新闻发布</span></a></li>
		   <li><a href="message.php"><img src="images/c2.png"/><span>留言查看</span></a></li>
		   <li><a href="exit.php"><img src="images/c3.png"/><span>退出</span></a></li>
		   
	   </div>
	   
	   <div class="ft">个人网站管理@2021</div>
	   
   </div>