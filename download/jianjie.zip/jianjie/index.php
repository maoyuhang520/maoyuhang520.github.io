<!DOCTYPE html>
<html>
<head>
<!--网页格式文本，编码UTF-8  -->
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>web作业</title>
<!--链接外部css样式表文件-->
<link href="css/style.css" rel="stylesheet" type="text/css" />
<!--插入背景音乐-自动播放-无限循环 -->
<embed autostart="true" loop="-1" controls="ControlPanel" width="0" height="0" src="music/1.mp3">
</head>
<body>
<!--主体框导航条  -->
<?php include"header.php";?> 


<div class="cleaner"></div>
<div id="container">
  <div class="dm"> 
    <!-- 代码 开始 -->
    <div id="yc-mod-slider">
		<!--wrapper达到俩边留空目的-->
      <div class="wrapper">
		  <!--jQuery幻灯片插件-->
        <div id="slideshow" class="box_skitter fn-clear">
          <ul><!--放入图片-->
            <li> <img class="cubeRandom" src="images/dm1.jpg" /></li>
            <li> <img   class="cubeRandom" src="images/dm2.jpg" /></li>
            <li> <img   class="cubeRandom" src="images/dm3.jpg" /></li>
          </ul>
        </div>
		<!--导入幻灯片效果脚本-->
        <script type="text/javascript" src="js/slideshow.js"></script> 
      </div>
    </div>
    <!-- 代码 结束 --> 
  </div>
  <div class="index_main">
      <span>
         我是软件11805班的毛宇航，来自湖北武汉。平时喜欢运动，虽然我的个子不高，但是特别喜欢打羽毛球，羽毛球已经是我生命中不可缺少的一部分。平时的生活中，我比较活泼开朗，认识许多志同道合的朋友，在步入大学后，也是能够很快的适应大学生活。我经常和室友，球队的朋友外出聚会等，在朋友遇到困难时，也能够主动伸出援助之手...
      </span><!--表格布局-->
  <div> <table border="0" cellspacing="10" cellpadding="10">
  <tr><!--横放图片-->
    <td><img src="images/k1.jpg" /></td>
     <td><img src="images/k2.jpg" /></td>
     <td><img src="images/k3.jpg" /></td>
  </tr> 
</table>
</div>
  <p></p>
  </div>
  <div class="share"><!--清除子集的浮动-->
    <div class="cleaner"></div>
  </div>
  <div id="footer"> Copyright © 毛宇航个人主页</div>
</div>
<!-- End Of Container -->
</body>
</html>
